package figuras;

import java.awt.Color;

/**
 * Representa una figura con un centro y color.
 */
public abstract class Figura {
    private Punto centro;
    private Color color;

    /**
     * Crea una Figura.
     *
     * @param x coordenada x de la figura.
     * @param y coordenada y de la figura.
     * @param color es el color de la figura.
     */
    public Figura(double x, double y, Color color) {
        centro = new Punto(x, y);
        this.color = color;
    }

    /**
     * Obtiene la coordenada X del centro.
     *
     * @return La coordenada X.
     */
    public double getXCentro() {
        return centro.getX();
    }

    /**
     * Recibe la coordenada Y del centro.
     *
     * @return coordenada Y.
     */
    public double getYCentro() {
        return centro.getY();
    }

    /**
     * Recibe el color.
     *
     * @return el color.
     */
    public Color getColor() {
        return color;
    }

    /**
     * Estabelece la coordenada X del centro de la figura.
     *
     * @param X es la nueva coordenada X del centro.
     */
    public void setXCentro(double x) {
        centro.setX(x);
    }

    /**
     * Establece la coordenada Y del centro de la figura.
     *
     * @param Y es la nueva coordenada Y del centro.
     */
    public void setYCentro(double y) {
        centro.setY(y);
    }

    /**
     * Establece el color de la figura.
     *
     * @param color es el nuevo color.
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Calcula el perímetro de la figura.
     */
    public abstract double perimetro();

    /**
     * Calcula el área de la figura.
     */
    public abstract double area();

    /**
     * Compara el área de una figura con otra.
     *
     * @param otraFigura es la figura que se va a comparar.
     * @return 1 si esta figura tiene un área mayor, -1 si es menor y 0 si son iguales.
     */
    public int esMayorQue(Figura otraFigura) {
        if (this.area() > otraFigura.area())
            return 1;
        else if (this.area() < otraFigura.area())
            return -1;
        else
            return 0;
    }
}
