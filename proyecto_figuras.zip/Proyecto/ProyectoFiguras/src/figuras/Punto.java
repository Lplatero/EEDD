package figuras;

/**
 * Representa un punto.
 */
public class Punto {
    private double x;
    private double y;

    /**
     * Crea un nuevo Punto en (0, 0).
     */
    public Punto() {
        x = 0;
        y = 0;
    }

    /**
     * Crea un nuevo Punto con las coordenadas especificadas.
     *
     * @param x es la coordenada x del punto.
     * @param y es la coordenada y del punto.
     */
    public Punto(double x, double y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Crea un nuevo Punto copiando las coordenadas de otro punto.
     *
     * @param p es el punto ha ser copiado.
     */
    public Punto(Punto p) {
        x = p.x;
        y = p.y;
    }

    /**
     * Recibe la coordenada x del punto.
     *
     * @return la coordenada x.
     */
    public double getX() {
        return x;
    }

    /**
     * Recibe la coordenada y del punto.
     *
     * @return la coordenada y.
     */
    public double getY() {
        return y;
    }

    /**
     * Establece la coordenada x del punto.
     *
     * @param x es la nueva coordenada x.
     */
    public void setX(double x) {
        this.x = x;
    }

    /**
     * Establece la coordenada y del punto.
     *
     * @param y es la nueva coordenada y.
     */
    public void setY(double y) {
        this.y = y;
    }

    /**
     * Calcula la distancia de este punto a otro punto.
     *
     * @param p es el punto al cual calcular la distancia.
     * @return la distancia entre los puntos.
     */
    public double distancia(Punto p) {
        return Math.sqrt(Math.pow(p.x - this.x, 2) + Math.pow(p.y - this.y, 2));
    }

    /**
     * Devuelve un nuevo punto que es simétrico a este respecto al eje y.
     *
     * @return Un nuevo punto simétrico.
     */
    public Punto simétrico() {
        Punto nuevoP = new Punto(this.x * -1, this.y);
        return nuevoP;
    }

    /**
     * Compara este punto con otro punto.
     *
     * @param p es el punto a comparar.
     * @return true si los puntos tienen las mismas coordenadas, false en caso contrario.
     */
    public boolean compara(Punto p) {
        if (p.x == x && p.y == y) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Devuelve las coordenadas de un punto.
     *
     * @return las coordenadas de un punto.
     */
    public String toString() {
        return "(" + getX() + "," + getY() + ")";
    }
}
