package figuras;

import java.awt.Color;

/**
 * Representa un cuadrado que es una clase hija del rectángulo.
 */
public class Cuadrado extends Rectangulo {

    /**
     * Crea una nueva instancia de Cuadrado.
     *
     * @param X la coordenada X del centro del cuadrado.
     * @param Y La coordenada Y del centro del cuadrado.
     * @param color es el color del cuadrado.
     * @param lado es el tamaño de los lados del cuadrado.
     */
    public Cuadrado(double x, double y, Color color, double lado) {
        super(x, y, color, lado, lado);
    }
}
