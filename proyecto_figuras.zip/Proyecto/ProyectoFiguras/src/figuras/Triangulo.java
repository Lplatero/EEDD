package figuras;

import java.awt.Color;

/**
 * Clase triangulo que es hija de la clase Figura.
 */
public class Triangulo extends Figura {
    private double lado1;
    private double lado2;
    private double lado3;

    /**
     * Crea un nuevo Triangulo.
     *
     * @param X es la coordenada X del centro.
     * @param Y es la coordenada Y del centro.
     * @param color es el color del triángulo.
     * @param lado1 es el tamaño del primer lado.
     * @param lado2 es el tamaño del segundo lado.
     * @param lado3 es el tamaño del tercer lado.
     */
    public Triangulo(double x, double y, Color color, double lado1, double lado2, double lado3) {
        super(x, y, color);
        this.lado1 = lado1;
        this.lado2 = lado2;
        this.lado3 = lado3;
    }

    /**
     * Obtiene el tamaño del primer lado del triángulo.
     *
     * @return el tamaño del primer lado.
     */
    public double getLado1() {
        return lado1;
    }

    /**
     * Obtiene el tamaño del segundo lado del triángulo.
     *
     * @return el tamaño del segundo lado.
     */
    public double getLado2() {
        return lado2;
    }

    /**
     * Obtiene el tamaño del tercer lado del triángulo.
     *
     * @return el tamaño del tercer lado.
     */
    public double getLado3() {
        return lado3;
    }

    /**
     * Establece el tamaño del primer lado del triángulo.
     *
     * @param lado1 nuevo tamaño del primer lado.
     */
    public void setLado1(double lado1) {
        this.lado1 = lado1;
    }

    /**
     * Establece el tamaño del segundo lado del triángulo.
     *
     * @param lado2 nuevo tamaño del segundo lado.
     */
    public void setLado2(double lado2) {
        this.lado2 = lado2;
    }

    /**
     * Establece el tamaño del tercer lado del triángulo.
     *
     * @param lado3 nuevo tamaño del tercer lado.
     */
    public void setLado3(double lado3) {
        this.lado3 = lado3;
    }

    /**
     * Calcula el perímetro del triángulo.
     *
     * @return el perímetro del triángulo.
     */
    public double perimetro() {
        return lado1 + lado2 + lado3;
    }

    /**
     * Calcula el área del triángulo.
     *
     * @return el área del triángulo.
     */
    public double area() {
        double sp = perimetro() / 2;
        return Math.sqrt(sp * (sp - lado1) * (sp - lado2) * (sp - lado3));
    }
}
