package figuras;

import java.awt.Color;

/**
 * Representa un rectángulo con una base y una altura.
 */
public class Rectangulo extends Figura {
    private double base;
    private double altura;

    /**
     * Crea un nuevo Rectangulo.
     *
     * @param X la coordenada X del centro del rectángulo.
     * @param Y la coordenada Y del centro del rectángulo.
     * @param color es el color del rectángulo.
     * @param base es la base del rectángulo.
     * @param altura es la altura del rectángulo.
     */
    public Rectangulo(double x, double y, Color color, double base, double altura) {
        super(x, y, color);
        this.base = base;
        this.altura = altura;
    }

    /**
     * Recibe la base del rectángulo.
     *
     * @return la base.
     */
    public double getBase() {
        return base;
    }

    /**
     * Recibe la altura del rectángulo.
     *
     * @return la altura.
     */
    public double getAltura() {
        return altura;
    }

    /**
     * Establece la base del rectángulo.
     *
     * @param base es la nueva base.
     */
    public void setBase(double base) {
        this.base = base;
    }

    /**
     * Establece la altura del rectángulo.
     *
     * @param altura la nueva altura.
     */
    public void setAltura(double altura) {
        this.altura = altura;
    }

    /**
     * Calcula el perímetro del rectángulo.
     *
     * @return el perímetro del rectángulo.
     */
    public double perimetro() {
        return 2 * base + 2 * altura;
    }

    /**
     * Calcula el área del rectángulo.
     *
     * @return el área del rectángulo.
     */
    public double area() {
        return base * altura;
    }
}
